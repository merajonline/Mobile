package testPack;

import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.Mobile.dao.ProductDAO;
import com.niit.Mobile.model.Product;

public class ProductTest 
{
	public static void main(String args[])
	{
		AnnotationConfigApplicationContext ap = new AnnotationConfigApplicationContext();
		
		ap.scan("com.niit");
		ap.refresh();
		
		ProductDAO productDAO = (ProductDAO)ap.getBean("productDAO");
		Product product = (Product)ap.getBean("product");
		
		product.setId("PRD_001");
		product.setName("Camera");
		product.setPrice(50000);
		product.setDes("NIKON N2X");
		
		productDAO.addProduct(product);
		
	}
}
