
package com.niit.Mobile.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class HelloController
{
	@RequestMapping("/")
	public String getIndex()
	{
		System.out.println("Landing page is Loaded.....");
		return "index";
		
	}
	/*@RequestMapping("/login")
	public String getLogin()
	{
		System.out.println("Login page is Loaded.....");
		return "login";
		
	}*/
}

































