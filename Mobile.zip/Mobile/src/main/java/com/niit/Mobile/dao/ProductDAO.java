package com.niit.Mobile.dao;

import com.niit.Mobile.model.Product;

public interface ProductDAO 
{
	public void addProduct(Product product);
}
